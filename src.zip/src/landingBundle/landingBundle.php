<?php

namespace landingBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class landingBundle extends Bundle
{
}
